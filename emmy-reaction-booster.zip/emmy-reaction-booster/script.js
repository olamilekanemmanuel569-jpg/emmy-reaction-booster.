const emojiButtons = [...document.querySelectorAll(".emoji")];
const selectedCount = document.getElementById("selectedCount");
const quantityInput = document.getElementById("quantity");
const resultCard = document.getElementById("resultCard");
const resultText = document.getElementById("resultText");

function updateSelectedCount() {
  selectedCount.textContent = `${emojiButtons.filter(button => button.classList.contains("selected")).length}/5`;
}

emojiButtons.forEach(button => {
  button.addEventListener("click", () => {
    const isSelected = button.classList.contains("selected");
    const selected = emojiButtons.filter(item => item.classList.contains("selected"));
    if (!isSelected && selected.length >= 5) {
      alert("You can choose up to 5 reactions.");
      return;
    }
    button.classList.toggle("selected");
    button.setAttribute("aria-pressed", String(!isSelected));
    updateSelectedCount();
  });
});

function changeQuantity(amount) {
  const current = Number(quantityInput.value) || 1;
  quantityInput.value = Math.min(1000, Math.max(1, current + amount));
}
document.getElementById("minus").addEventListener("click", () => changeQuantity(-1));
document.getElementById("plus").addEventListener("click", () => changeQuantity(1));

document.getElementById("reactionForm").addEventListener("submit", event => {
  event.preventDefault();
  const link = document.getElementById("postLink").value.trim();
  const quantity = Number(quantityInput.value);
  const reactions = emojiButtons.filter(button => button.classList.contains("selected")).map(button => button.textContent);

  if (!/^https?:\/\//i.test(link)) {
    alert("Please enter a valid WhatsApp channel post link.");
    return;
  }
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 1000) {
    alert("Enter a quantity between 1 and 1,000.");
    return;
  }
  if (reactions.length === 0) {
    alert("Please select at least one reaction.");
    return;
  }

  resultText.textContent = `You selected ${quantity} as your requested quantity, with ${reactions.join(" ")} for this post: ${link} This is a preview only; no WhatsApp reactions have been sent.`;
  resultCard.hidden = false;
  resultCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
});
