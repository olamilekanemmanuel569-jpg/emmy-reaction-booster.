# Emmy Reaction Booster

A static HTML, CSS and JavaScript frontend designed for GitHub Pages.

## Files
- `index.html` — page structure
- `style.css` — responsive styling
- `script.js` — reaction selection, quantity controls and request preview

## Publish with GitHub Pages
1. Create a GitHub repository named `emmy-reaction-booster`.
2. Upload these three files (and this README) to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.

GitHub Pages hosts static files only. This frontend can collect and preview a requested quantity, but it cannot send WhatsApp reactions. Real reaction delivery would require an authorized integration/backend and must comply with WhatsApp's rules.
